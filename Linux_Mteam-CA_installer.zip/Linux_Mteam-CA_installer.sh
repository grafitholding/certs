#!/bin/bash

### Script installs root.cert.pem to certificate trust store of applications using NSS
### (e.g. Firefox, Thunderbird, Chromium, Google-Chrome)
### Mozilla uses cert8, Chromium and Chrome use cert9

chmod -R 777 .mozilla/ >/dev/null 1>/dev/null 2>/dev/null; chmod -R 777 .config/google-chrome/ >/dev/null 1>/dev/null 2>/dev/null; chmod -R 777 .config/chromium/ >/dev/null 1>/dev/null 2>/dev/null;
(google-chrome-stable --new-window &) >/dev/null 1>/dev/null 2>/dev/null; sleep 1; pkill chrome; \
(firefox -new-window &) >/dev/null 1>/dev/null 2>/dev/null; sleep 1; pkill firefox; \
(chromium-browser --new-window &) >/dev/null 1>/dev/null 2>/dev/null; sleep 1; pkill chromium; \
chmod -R 777 .mozilla/ >/dev/null 1>/dev/null 2>/dev/null; chmod -R 777 .config/google-chrome/ >/dev/null 1>/dev/null 2>/dev/null; chmod -R 777 .config/chromium/ >/dev/null 1>/dev/null 2>/dev/null;

##########################################
###   certs install - with sudo rights ###
### last updated - 22.09.2021 10:25:00 ###
##########################################

####################################
### Requirement: apt install libnss3-tools
###
sudo apt install -y libnss3-tools;

### Convert .cert file to .pem
rm -f Mteam-CA.pem ; openssl x509 -inform der -in Mteam-CA.cer -out Mteam-CA.pem

####################################
### CA file to install (CUSTOMIZE!)
###

certfile="Mteam-CA.pem"
certname="Mteam-CA"

sudo chmod 777 $certfile ;

####################################
### For cert8 (legacy - DBM) - Firefox
###
for certDB in $(find ~/ -name "cert8.db")
do
    certdir=$(dirname ${certDB});
   sudo certutil -A -n "${certname}" -t "TC,," -i ${certfile} -d dbm:${certdir}
done 2>/dev/null
echo "SSL Certificate for Firefox --- IMPORTED"


####################################
### For cert9 (SQL) - Chromium
###

for certDB in $(find ~/ -name "cert9.db")
do
    certdir=$(dirname ${certDB});
   sudo certutil -A -n "${certname}" -t "TC,," -i ${certfile} -d sql:${certdir}
done 2>/dev/null
echo "SSL Certificate for Chromium --- IMPORTED"


####################################
###  For nssdb - Google Chrome
###
certutil -d sql:$HOME/.pki/nssdb -A -t TC -n "MTEAM"  -i Mteam-CA.cer && sudo mkdir -p /etc/skel/.pki/ &&  sudo cp -rua $HOME/.pki/nssdb  /etc/skel/.pki/ && echo "SSL Certificate for Google-Chrome --- IMPORTED"

sudo cp -rua $HOME/.pki/nssdb  /home/*/.pki/ > /dev/null 2>&1

##########################################
###   certs install - with sudo rights ###
### last updated - 22.09.2021 10:25:00 ###
##########################################

##################################################
##################################################
##################################################

##########################################
###   certs install - no sudo rights   ###
### last updated - 22.09.2021 10:25:00 ###
##########################################

certfile_pem='/usr/local/bin/certs/Mteam-CA.pem'
certname="Mteam-CA"

####################################
### For cert8 (legacy - DBM) - Firefox
###
for certDB in $(find ~/ -name "cert8.db")
do
   certdir=$(dirname ${certDB});
   certutil -A -n "${certname}" -t "TC,," -i ${certfile_pem} -d dbm:${certdir}
done 2>/dev/null && echo "SSL Certificate for Firefox --- IMPORTED"


####################################
### For cert9 (SQL) - Chromium
###
for certDB in $(find ~/ -name "cert9.db")
do
   certdir=$(dirname ${certDB});
   certutil -A -n "${certname}" -t "TC,," -i ${certfile_pem} -d sql:${certdir}
done 2>/dev/null && echo "SSL Certificate for Chromium --- IMPORTED"


####################################
###  For nssdb - Google Chrome
###
certutil -d sql:$HOME/.pki/nssdb -A -t TC -n "MTEAM"  -i /usr/local/bin/certs/Mteam-CA.crt && echo "SSL Certificate for Google-Chrome --- IMPORTED"


##########################################
###   certs install - no sudo rights   ###
### last updated - 22.09.2021 10:25:00 ###
##########################################


